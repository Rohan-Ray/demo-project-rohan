const express=require('express');
const bodyParser=require('body-parser');//body parser to fetch the request and convert it to object
const mongoose=require('mongoose'); // for connecting to mongoDB
const Post=require('./models/post'); // fetches the Post object  
const app=express();
mongoose.connect("mongodb+srv://rohanray298:5UUBmzyozGeD6Hl8@cluster0-fjyuj.mongodb.net/node-angular?retryWrites=true&w=majority", { useUnifiedTopology: true, useNewUrlParser: true, useCreateIndex: true })
.then(()=>{
    console.log("connected to MongoDB");
})
.catch(()=>{
    console.log("connection failed");
});
app.use(bodyParser.json()); //returns a midlleware to return json data
app.use(bodyParser.urlencoded({extended:false})); // parse url encoded data
app.use((req,res,next)=>{
    res.setHeader("Access-Control-Allow-Origin","*");// irrespective of where the app is running on its allowed to acces our resources
    res.setHeader("Access-Control-Allow-Headers",
    "Origin, X-Requested-With, Content-Type, Accept"); //incoming requests may heva these extra headers
    res.setHeader("Access-COnteol-Allow-Methos",
    "GET, POST, PATCH, DELETE, OPTIONS"); 
    next();
});

app.post("/api/posts",(req,res,next) => {


    // const post=req.body;// field added by body parser
    const post=new Post({
            title:req.body.title,
            content:req.body.content
    });
    // console.log(post);
    post.save();
    res.status(201).json({
        message:"Post added successully"
    });
})
app.get("/api/posts",(req,res,next)=>{
    // console.log("first middleware");
    // next();
    // const posts=[
    //     {
    //         id:"id1",
    //         title:"First Note",
    //         content:"Welcome to note 1. You will get to know about note 1"
    //     },
    //     {
    //         id:"id2",
    //         title:"Second Note",
    //         content:"Welcome to note 2. You will get to know about note 2"
    //     }
    // ];
    Post.find() // find is a static method defined on th epost object
    .then((documents)=>{
        console.log(documents);
         res.status(200).json({
        message:"Posts fetched successfully",
        posts:documents
    });
    });
   

});

// app.use((req,res,next)=>{
//     res.send('Hello');
// });

module.exports=app;