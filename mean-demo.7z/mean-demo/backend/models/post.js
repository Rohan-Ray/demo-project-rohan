const mongoose=require('mongoose');

//schema defined
const postMongooseSchema=mongoose.Schema({
    title:{type:String, required:true},
    content:{type:String, required:true}
});

//model defined

module.exports=mongoose.model('Post',postMongooseSchema);
